export SLACK_CLIENT_ID='Your Slack Client Id'
export SLACK_CLIENT_SECRET='Your Slack Client Secret'
export SLACK_VERIFICATION_TOKEN='Your Slack Verification Token'
export GCP_API_KEY='Your GCP API key'
